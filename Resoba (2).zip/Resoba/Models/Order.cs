using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Resoba.Models
{
    public enum OrderStatus
    {
        Новый,
        ВОбработке,
        Отправлен,
        Выполнен,
        Отменён
    }

    public enum ClientType
    {
        ФЛ,
        ЮЛ
    }

    public class Order
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public User User { get; set; } = null!;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public OrderStatus Status { get; set; } = OrderStatus.Новый;
        public ClientType ClientType { get; set; }

        [MaxLength(20)]
        public string Phone { get; set; } = string.Empty;

        [MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [MaxLength(500)]
        public string Address { get; set; } = string.Empty;

        [MaxLength(200)]
        public string FullName { get; set; } = string.Empty;

        [MaxLength(300)]
        public string? CompanyName { get; set; }

        [MaxLength(12)]
        public string? Inn { get; set; }

        [MaxLength(200)]
        public string? ContactPerson { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        public ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
    }
}
