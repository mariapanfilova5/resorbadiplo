namespace Resoba.Models
{
    public class ProductImage
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public Product Product { get; set; } = null!;
        public string ImagePath { get; set; } = string.Empty;
    }
}
