using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using Resoba.Models;

namespace Resoba.ViewModels
{
    public class ProductEditViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Введите артикул")]
        [Display(Name = "Артикул")]
        public string Article { get; set; } = string.Empty;

        [Required(ErrorMessage = "Введите название")]
        [Display(Name = "Название")]
        public string Name { get; set; } = string.Empty;

        [Display(Name = "Описание")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Введите цену")]
        [Display(Name = "Цена")]
        [Range(0.01, 999999999)]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Введите количество")]
        [Display(Name = "Остаток на складе")]
        [Range(0, int.MaxValue)]
        public int Stock { get; set; }

        [Required(ErrorMessage = "Выберите категорию")]
        [Display(Name = "Категория")]
        public int CategoryId { get; set; }

        [Display(Name = "Новые фотографии")]
        public List<IFormFile>? NewImages { get; set; }

        public List<ProductImage> ExistingImages { get; set; } = new();
    }
}
