using Resoba.Models;

namespace Resoba.ViewModels
{
    public class CatalogViewModel
    {
        public List<Product> Products { get; set; } = new();
        public List<Category> Categories { get; set; } = new();
        public int? SelectedCategoryId { get; set; }
        public string? SearchQuery { get; set; }
    }
}
