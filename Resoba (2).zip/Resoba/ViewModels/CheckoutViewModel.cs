using System.ComponentModel.DataAnnotations;
using Resoba.Models;

namespace Resoba.ViewModels
{
    public class CheckoutViewModel
    {
        [Required(ErrorMessage = "Введите телефон")]
        [Display(Name = "Телефон")]
        [Phone]
        public string Phone { get; set; } = string.Empty;

        [Required(ErrorMessage = "Введите email")]
        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Выберите тип клиента")]
        [Display(Name = "Тип клиента")]
        public ClientType ClientType { get; set; }

        [Required(ErrorMessage = "Введите ФИО")]
        [Display(Name = "ФИО")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Введите адрес доставки")]
        [Display(Name = "Адрес доставки")]
        public string Address { get; set; } = string.Empty;

        [Display(Name = "Название организации")]
        public string? CompanyName { get; set; }

        [Display(Name = "ИНН")]
        public string? Inn { get; set; }

        [Display(Name = "Контактное лицо")]
        public string? ContactPerson { get; set; }
    }
}
