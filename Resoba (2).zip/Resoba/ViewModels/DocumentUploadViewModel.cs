using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Resoba.ViewModels
{
    public class DocumentUploadViewModel
    {
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Выберите тип документа")]
        [Display(Name = "Тип документа")]
        public string DocType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Выберите файл")]
        [Display(Name = "Файл")]
        public IFormFile File { get; set; } = null!;
    }
}
