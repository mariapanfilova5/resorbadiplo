using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Resoba.ViewModels
{
    public class ProductCreateViewModel
    {
        [Required(ErrorMessage = "Введите артикул")]
        [Display(Name = "Артикул")]
        public string Article { get; set; } = string.Empty;

        [Required(ErrorMessage = "Введите название")]
        [Display(Name = "Название")]
        public string Name { get; set; } = string.Empty;

        [Display(Name = "Описание")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Введите цену")]
        [Display(Name = "Цена")]
        [Range(0.01, 999999999, ErrorMessage = "Цена должна быть больше 0")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Введите количество")]
        [Display(Name = "Остаток на складе")]
        [Range(0, int.MaxValue)]
        public int Stock { get; set; }

        [Required(ErrorMessage = "Выберите категорию")]
        [Display(Name = "Категория")]
        public int CategoryId { get; set; }

        [Display(Name = "Фотографии товара (до 3 шт.)")]
        public List<IFormFile>? Images { get; set; }
    }
}
