using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Resoba.Data;
using Resoba.Models;
using Resoba.ViewModels;

namespace Resoba.Controllers
{
    public class CatalogController : Controller
    {
        private readonly AppDbContext _db;
        private readonly UserManager<User> _userManager;

        public CatalogController(AppDbContext db, UserManager<User> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index(string? search, int? categoryId)
        {
            var query = _db.Products
                .Include(p => p.Category)
                .Include(p => p.Images)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.ToLower();
                query = query.Where(p => p.Name.ToLower().Contains(s) || p.Article.ToLower().Contains(s));
            }

            if (categoryId.HasValue && categoryId.Value > 0)
            {
                query = query.Where(p => p.CategoryId == categoryId.Value);
            }

            var model = new CatalogViewModel
            {
                Products = await query.OrderBy(p => p.Name).ToListAsync(),
                Categories = await _db.Categories.OrderBy(c => c.Name).ToListAsync(),
                SelectedCategoryId = categoryId,
                SearchQuery = search
            };

            if (User.Identity != null && User.Identity.IsAuthenticated)
            {
                var userId = _userManager.GetUserId(User);
                ViewBag.WishlistIds = await _db.WishlistItems
                    .Where(w => w.UserId == userId)
                    .Select(w => w.ProductId)
                    .ToListAsync();
            }

            return View(model);
        }

        public async Task<IActionResult> Details(int id)
        {
            var product = await _db.Products
                .Include(p => p.Category)
                .Include(p => p.Images)
                .Include(p => p.Documents)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (product == null)
                return NotFound();

            if (User.Identity != null && User.Identity.IsAuthenticated)
            {
                var userId = _userManager.GetUserId(User);
                ViewBag.IsInWishlist = await _db.WishlistItems
                    .AnyAsync(w => w.UserId == userId && w.ProductId == id);
            }

            return View(product);
        }
    }
}
