using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Resoba.Data;
using Resoba.Models;
using Resoba.ViewModels;

namespace Resoba.Controllers
{
    [Authorize]
    public class OrderController : Controller
    {
        private readonly AppDbContext _db;
        private readonly UserManager<User> _userManager;

        public OrderController(AppDbContext db, UserManager<User> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        [HttpGet]
        public async Task<IActionResult> Checkout()
        {
            var userId = _userManager.GetUserId(User);
            var cartItems = await _db.CartItems
                .Include(ci => ci.Product)
                .Where(ci => ci.UserId == userId)
                .ToListAsync();

            if (!cartItems.Any())
                return RedirectToAction("Index", "Cart");

            var user = await _userManager.GetUserAsync(User);
            var model = new CheckoutViewModel
            {
                Email = user?.Email ?? "",
                FullName = user?.FullName ?? ""
            };

            ViewBag.CartItems = cartItems;
            ViewBag.Total = cartItems.Sum(ci => ci.Product.Price * ci.Quantity);

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout(CheckoutViewModel model)
        {
            var userId = _userManager.GetUserId(User);
            var cartItems = await _db.CartItems
                .Include(ci => ci.Product)
                .Where(ci => ci.UserId == userId)
                .ToListAsync();

            if (!cartItems.Any())
                return RedirectToAction("Index", "Cart");

            if (model.ClientType == ClientType.ЮЛ)
            {
                if (string.IsNullOrWhiteSpace(model.CompanyName))
                    ModelState.AddModelError("CompanyName", "Введите название организации");
                if (string.IsNullOrWhiteSpace(model.Inn))
                    ModelState.AddModelError("Inn", "Введите ИНН");
                if (string.IsNullOrWhiteSpace(model.ContactPerson))
                    ModelState.AddModelError("ContactPerson", "Введите контактное лицо");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.CartItems = cartItems;
                ViewBag.Total = cartItems.Sum(ci => ci.Product.Price * ci.Quantity);
                return View(model);
            }

            var order = new Order
            {
                UserId = userId!,
                CreatedAt = DateTime.Now,
                Status = OrderStatus.Новый,
                ClientType = model.ClientType,
                Phone = model.Phone,
                Email = model.Email,
                Address = model.Address,
                FullName = model.FullName,
                CompanyName = model.CompanyName,
                Inn = model.Inn,
                ContactPerson = model.ContactPerson,
                TotalAmount = cartItems.Sum(ci => ci.Product.Price * ci.Quantity)
            };

            foreach (var ci in cartItems)
            {
                order.Items.Add(new OrderItem
                {
                    ProductId = ci.ProductId,
                    Quantity = ci.Quantity,
                    PriceAtMoment = ci.Product.Price
                });

                ci.Product.Stock -= ci.Quantity;
                if (ci.Product.Stock < 0) ci.Product.Stock = 0;
            }

            _db.Orders.Add(order);
            _db.CartItems.RemoveRange(cartItems);
            await _db.SaveChangesAsync();

            return RedirectToAction("Confirmation", new { id = order.Id });
        }

        public async Task<IActionResult> Confirmation(int id)
        {
            var userId = _userManager.GetUserId(User);
            var order = await _db.Orders
                .Include(o => o.Items)
                    .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == id && o.UserId == userId);

            if (order == null)
                return NotFound();

            return View(order);
        }

        public async Task<IActionResult> MyOrders()
        {
            var userId = _userManager.GetUserId(User);
            var orders = await _db.Orders
                .Include(o => o.Items)
                .Where(o => o.UserId == userId)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();

            return View(orders);
        }

        public async Task<IActionResult> Details(int id)
        {
            var userId = _userManager.GetUserId(User);
            var order = await _db.Orders
                .Include(o => o.Items)
                    .ThenInclude(oi => oi.Product)
                        .ThenInclude(p => p.Images)
                .FirstOrDefaultAsync(o => o.Id == id && o.UserId == userId);

            if (order == null)
                return NotFound();

            return View(order);
        }
    }
}
