using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Resoba.Data;
using Resoba.Models;

namespace Resoba.Controllers
{
    [Authorize]
    public class WishlistController : Controller
    {
        private readonly AppDbContext _db;
        private readonly UserManager<User> _userManager;

        public WishlistController(AppDbContext db, UserManager<User> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var userId = _userManager.GetUserId(User);
            var items = await _db.WishlistItems
                .Include(w => w.Product)
                    .ThenInclude(p => p.Images)
                .Include(w => w.Product)
                    .ThenInclude(p => p.Category)
                .Where(w => w.UserId == userId)
                .OrderByDescending(w => w.AddedAt)
                .ToListAsync();

            return View(items);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Toggle(int productId, string? returnUrl)
        {
            var userId = _userManager.GetUserId(User);
            var existing = await _db.WishlistItems
                .FirstOrDefaultAsync(w => w.UserId == userId && w.ProductId == productId);

            if (existing != null)
            {
                _db.WishlistItems.Remove(existing);
                TempData["Success"] = "Товар удалён из избранного";
            }
            else
            {
                _db.WishlistItems.Add(new WishlistItem
                {
                    UserId = userId!,
                    ProductId = productId
                });
                TempData["Success"] = "Товар добавлен в избранное";
            }

            await _db.SaveChangesAsync();

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Index", "Catalog");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Remove(int wishlistItemId)
        {
            var userId = _userManager.GetUserId(User);
            var item = await _db.WishlistItems
                .FirstOrDefaultAsync(w => w.Id == wishlistItemId && w.UserId == userId);

            if (item != null)
            {
                _db.WishlistItems.Remove(item);
                await _db.SaveChangesAsync();
                TempData["Success"] = "Товар удалён из избранного";
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MoveToCart(int wishlistItemId)
        {
            var userId = _userManager.GetUserId(User);
            var item = await _db.WishlistItems
                .Include(w => w.Product)
                .FirstOrDefaultAsync(w => w.Id == wishlistItemId && w.UserId == userId);

            if (item != null && item.Product.Stock > 0)
            {
                var cartItem = await _db.CartItems
                    .FirstOrDefaultAsync(c => c.UserId == userId && c.ProductId == item.ProductId);

                if (cartItem != null)
                {
                    cartItem.Quantity += 1;
                }
                else
                {
                    _db.CartItems.Add(new CartItem
                    {
                        UserId = userId!,
                        ProductId = item.ProductId,
                        Quantity = 1
                    });
                }

                _db.WishlistItems.Remove(item);
                await _db.SaveChangesAsync();
                TempData["Success"] = "Товар перемещён в корзину";
            }

            return RedirectToAction("Index");
        }
    }
}
