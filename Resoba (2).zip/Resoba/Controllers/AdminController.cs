using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Resoba.Data;
using Resoba.Models;
using Resoba.ViewModels;

namespace Resoba.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IWebHostEnvironment _env;

        public AdminController(AppDbContext db, IWebHostEnvironment env)
        {
            _db = db;
            _env = env;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.ProductCount = await _db.Products.CountAsync();
            ViewBag.OrderCount = await _db.Orders.CountAsync();
            ViewBag.CategoryCount = await _db.Categories.CountAsync();
            ViewBag.NewOrderCount = await _db.Orders.CountAsync(o => o.Status == OrderStatus.Новый);
            return View();
        }

        public async Task<IActionResult> Products()
        {
            var products = await _db.Products
                .Include(p => p.Category)
                .Include(p => p.Images)
                .OrderBy(p => p.Name)
                .ToListAsync();
            return View(products);
        }

        [HttpGet]
        public async Task<IActionResult> CreateProduct()
        {
            ViewBag.Categories = new SelectList(await _db.Categories.ToListAsync(), "Id", "Name");
            return View(new ProductCreateViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateProduct(ProductCreateViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = new SelectList(await _db.Categories.ToListAsync(), "Id", "Name");
                return View(model);
            }

            var product = new Product
            {
                Article = model.Article,
                Name = model.Name,
                Description = model.Description,
                Price = model.Price,
                Stock = model.Stock,
                CategoryId = model.CategoryId
            };

            _db.Products.Add(product);
            await _db.SaveChangesAsync();

            if (model.Images != null && model.Images.Count > 0)
            {
                var count = 0;
                foreach (var img in model.Images)
                {
                    if (count >= 3) break;
                    if (img.Length > 0)
                    {
                        var fileName = $"{Guid.NewGuid()}{Path.GetExtension(img.FileName)}";
                        var filePath = Path.Combine(_env.WebRootPath, "uploads", "products", fileName);
                        using var stream = new FileStream(filePath, FileMode.Create);
                        await img.CopyToAsync(stream);

                        _db.ProductImages.Add(new ProductImage
                        {
                            ProductId = product.Id,
                            ImagePath = $"/uploads/products/{fileName}"
                        });
                        count++;
                    }
                }
                await _db.SaveChangesAsync();
            }

            return RedirectToAction("Products");
        }

        [HttpGet]
        public async Task<IActionResult> EditProduct(int id)
        {
            var product = await _db.Products
                .Include(p => p.Images)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (product == null)
                return NotFound();

            ViewBag.Categories = new SelectList(await _db.Categories.ToListAsync(), "Id", "Name", product.CategoryId);

            var model = new ProductEditViewModel
            {
                Id = product.Id,
                Article = product.Article,
                Name = product.Name,
                Description = product.Description,
                Price = product.Price,
                Stock = product.Stock,
                CategoryId = product.CategoryId,
                ExistingImages = product.Images.ToList()
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProduct(ProductEditViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model.ExistingImages = await _db.ProductImages.Where(pi => pi.ProductId == model.Id).ToListAsync();
                ViewBag.Categories = new SelectList(await _db.Categories.ToListAsync(), "Id", "Name", model.CategoryId);
                return View(model);
            }

            var product = await _db.Products.FindAsync(model.Id);
            if (product == null)
                return NotFound();

            product.Article = model.Article;
            product.Name = model.Name;
            product.Description = model.Description;
            product.Price = model.Price;
            product.Stock = model.Stock;
            product.CategoryId = model.CategoryId;

            if (model.NewImages != null && model.NewImages.Count > 0)
            {
                var existingCount = await _db.ProductImages.CountAsync(pi => pi.ProductId == model.Id);
                var count = 0;
                foreach (var img in model.NewImages)
                {
                    if (existingCount + count >= 3) break;
                    if (img.Length > 0)
                    {
                        var fileName = $"{Guid.NewGuid()}{Path.GetExtension(img.FileName)}";
                        var filePath = Path.Combine(_env.WebRootPath, "uploads", "products", fileName);
                        using var stream = new FileStream(filePath, FileMode.Create);
                        await img.CopyToAsync(stream);

                        _db.ProductImages.Add(new ProductImage
                        {
                            ProductId = product.Id,
                            ImagePath = $"/uploads/products/{fileName}"
                        });
                        count++;
                    }
                }
            }

            await _db.SaveChangesAsync();
            return RedirectToAction("Products");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteProductImage(int imageId, int productId)
        {
            var image = await _db.ProductImages.FindAsync(imageId);
            if (image != null)
            {
                var fullPath = Path.Combine(_env.WebRootPath, image.ImagePath.TrimStart('/'));
                if (System.IO.File.Exists(fullPath))
                    System.IO.File.Delete(fullPath);

                _db.ProductImages.Remove(image);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction("EditProduct", new { id = productId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _db.Products
                .Include(p => p.Images)
                .Include(p => p.Documents)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (product != null)
            {
                foreach (var img in product.Images)
                {
                    var fullPath = Path.Combine(_env.WebRootPath, img.ImagePath.TrimStart('/'));
                    if (System.IO.File.Exists(fullPath))
                        System.IO.File.Delete(fullPath);
                }

                foreach (var doc in product.Documents)
                {
                    var fullPath = Path.Combine(_env.WebRootPath, doc.FilePath.TrimStart('/'));
                    if (System.IO.File.Exists(fullPath))
                        System.IO.File.Delete(fullPath);
                }

                _db.Products.Remove(product);
                await _db.SaveChangesAsync();
            }

            return RedirectToAction("Products");
        }

        public async Task<IActionResult> Categories()
        {
            var categories = await _db.Categories.OrderBy(c => c.Name).ToListAsync();
            return View(categories);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateCategory(string name)
        {
            if (!string.IsNullOrWhiteSpace(name))
            {
                _db.Categories.Add(new Category { Name = name.Trim() });
                await _db.SaveChangesAsync();
            }
            return RedirectToAction("Categories");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var cat = await _db.Categories.FindAsync(id);
            if (cat != null)
            {
                var hasProducts = await _db.Products.AnyAsync(p => p.CategoryId == id);
                if (!hasProducts)
                {
                    _db.Categories.Remove(cat);
                    await _db.SaveChangesAsync();
                }
                else
                {
                    TempData["Error"] = "Нельзя удалить категорию, в которой есть товары";
                }
            }
            return RedirectToAction("Categories");
        }

        public async Task<IActionResult> ProductDocuments(int productId)
        {
            var product = await _db.Products
                .Include(p => p.Documents)
                .FirstOrDefaultAsync(p => p.Id == productId);

            if (product == null)
                return NotFound();

            ViewBag.Product = product;
            return View(product.Documents.ToList());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadDocument(DocumentUploadViewModel model)
        {
            if (!ModelState.IsValid)
                return RedirectToAction("ProductDocuments", new { productId = model.ProductId });

            var fileName = $"{Guid.NewGuid()}{Path.GetExtension(model.File.FileName)}";
            var filePath = Path.Combine(_env.WebRootPath, "uploads", "documents", fileName);
            using var stream = new FileStream(filePath, FileMode.Create);
            await model.File.CopyToAsync(stream);

            _db.ProductDocuments.Add(new ProductDocument
            {
                ProductId = model.ProductId,
                DocType = model.DocType,
                FileName = model.File.FileName,
                FilePath = $"/uploads/documents/{fileName}"
            });

            await _db.SaveChangesAsync();
            return RedirectToAction("ProductDocuments", new { productId = model.ProductId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteDocument(int docId, int productId)
        {
            var doc = await _db.ProductDocuments.FindAsync(docId);
            if (doc != null)
            {
                var fullPath = Path.Combine(_env.WebRootPath, doc.FilePath.TrimStart('/'));
                if (System.IO.File.Exists(fullPath))
                    System.IO.File.Delete(fullPath);

                _db.ProductDocuments.Remove(doc);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction("ProductDocuments", new { productId });
        }

        public async Task<IActionResult> Orders()
        {
            var orders = await _db.Orders
                .Include(o => o.User)
                .Include(o => o.Items)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();
            return View(orders);
        }

        public async Task<IActionResult> OrderDetails(int id)
        {
            var order = await _db.Orders
                .Include(o => o.User)
                .Include(o => o.Items)
                    .ThenInclude(oi => oi.Product)
                        .ThenInclude(p => p.Images)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
                return NotFound();

            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateOrderStatus(int orderId, OrderStatus status)
        {
            var order = await _db.Orders.FindAsync(orderId);
            if (order != null)
            {
                order.Status = status;
                await _db.SaveChangesAsync();
            }
            return RedirectToAction("OrderDetails", new { id = orderId });
        }
    }
}
