using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Resoba.Data;
using Resoba.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddIdentity<User, IdentityRole>(options =>
{
    options.Password.RequireDigit = false;
    options.Password.RequireLowercase = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequiredLength = 6;
})
.AddEntityFrameworkStores<AppDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
});

builder.Services.AddControllersWithViews();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<AppDbContext>();
    context.Database.Migrate();

    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
    var userManager = services.GetRequiredService<UserManager<User>>();

    if (!await roleManager.RoleExistsAsync("Admin"))
        await roleManager.CreateAsync(new IdentityRole("Admin"));
    if (!await roleManager.RoleExistsAsync("Client"))
        await roleManager.CreateAsync(new IdentityRole("Client"));

    var adminEmail = "admin@resoba.ru";
    var adminUser = await userManager.FindByEmailAsync(adminEmail);
    if (adminUser == null)
    {
        adminUser = new User
        {
            UserName = adminEmail,
            Email = adminEmail,
            FullName = "Администратор системы",
            EmailConfirmed = true
        };
        await userManager.CreateAsync(adminUser, "Admin123");
        await userManager.AddToRoleAsync(adminUser, "Admin");
    }

    var client1Email = "ivanov@mail.ru";
    var client1 = await userManager.FindByEmailAsync(client1Email);
    if (client1 == null)
    {
        client1 = new User
        {
            UserName = client1Email,
            Email = client1Email,
            FullName = "Иванов Сергей Петрович",
            EmailConfirmed = true
        };
        await userManager.CreateAsync(client1, "Client123");
        await userManager.AddToRoleAsync(client1, "Client");
    }

    var client2Email = "petrova@clinic.ru";
    var client2 = await userManager.FindByEmailAsync(client2Email);
    if (client2 == null)
    {
        client2 = new User
        {
            UserName = client2Email,
            Email = client2Email,
            FullName = "Петрова Анна Викторовна",
            EmailConfirmed = true
        };
        await userManager.CreateAsync(client2, "Client123");
        await userManager.AddToRoleAsync(client2, "Client");
    }

    var client3Email = "sidorov@hospital.ru";
    var client3 = await userManager.FindByEmailAsync(client3Email);
    if (client3 == null)
    {
        client3 = new User
        {
            UserName = client3Email,
            Email = client3Email,
            FullName = "Сидоров Дмитрий Алексеевич",
            EmailConfirmed = true
        };
        await userManager.CreateAsync(client3, "Client123");
        await userManager.AddToRoleAsync(client3, "Client");
    }

    if (!context.Categories.Any())
    {
        context.Categories.AddRange(
            new Category { Name = "Шовные материалы" },
            new Category { Name = "Хирургические инструменты" },
            new Category { Name = "Перевязочные средства" },
            new Category { Name = "Имплантаты и мембраны" },
            new Category { Name = "Расходные материалы" }
        );
        await context.SaveChangesAsync();
    }

    if (!context.Products.Any())
    {
        var catSuture = context.Categories.First(c => c.Name == "Шовные материалы");
        var catInstrument = context.Categories.First(c => c.Name == "Хирургические инструменты");
        var catBandage = context.Categories.First(c => c.Name == "Перевязочные средства");
        var catImplant = context.Categories.First(c => c.Name == "Имплантаты и мембраны");
        var catSupplies = context.Categories.First(c => c.Name == "Расходные материалы");

        var products = new List<Product>
        {
            new Product
            {
                Article = "RSB-SH001",
                Name = "Кетгут хромированный USP 2/0",
                Description = "Рассасывающийся шовный материал из натурального сырья. Применяется в общей хирургии, гинекологии и урологии для ушивания мягких тканей. Срок рассасывания 90 дней. Игла колющая 26 мм, длина нити 75 см.",
                Price = 450.00m,
                Stock = 100,
                CategoryId = catSuture.Id
            },
            new Product
            {
                Article = "RSB-SH002",
                Name = "ПГА (полигликолид) USP 3/0",
                Description = "Синтетический рассасывающийся плетёный шовный материал с антибактериальным покрытием. Прочность на разрыв сохраняется до 28 дней. Полное рассасывание 60-90 дней. Игла обратно-режущая 24 мм.",
                Price = 620.00m,
                Stock = 75,
                CategoryId = catSuture.Id
            },
            new Product
            {
                Article = "RSB-SH003",
                Name = "Шёлк хирургический USP 2/0",
                Description = "Нерассасывающийся плетёный шовный материал с высокой прочностью на узле. Покрытие силиконом для уменьшения травматичности. Длина нити 75 см, игла колющая 30 мм.",
                Price = 380.00m,
                Stock = 120,
                CategoryId = catSuture.Id
            },
            new Product
            {
                Article = "RSB-SH004",
                Name = "Полипропилен монофиламентный USP 4/0",
                Description = "Нерассасывающийся монофиламентный шовный материал для сердечно-сосудистой хирургии. Минимальная тканевая реакция, высокая биосовместимость. Игла колющая 17 мм.",
                Price = 890.00m,
                Stock = 50,
                CategoryId = catSuture.Id
            },
            new Product
            {
                Article = "RSB-HI001",
                Name = "Зажим Кохера прямой 160 мм",
                Description = "Хирургический кровоостанавливающий зажим из нержавеющей стали. Прямая форма, длина 160 мм, зубчатый замок. Подходит для стерилизации в автоклаве.",
                Price = 1250.00m,
                Stock = 30,
                CategoryId = catInstrument.Id
            },
            new Product
            {
                Article = "RSB-HI002",
                Name = "Скальпель хирургический одноразовый №10",
                Description = "Одноразовый хирургический скальпель с лезвием из углеродистой стали и эргономичной пластиковой ручкой. Стерильная упаковка. Размер лезвия №10 для разрезов кожи.",
                Price = 85.00m,
                Stock = 500,
                CategoryId = catInstrument.Id
            },
            new Product
            {
                Article = "RSB-HI003",
                Name = "Иглодержатель Майо-Хегара 180 мм",
                Description = "Иглодержатель из нержавеющей стали с твердосплавными вставками на рабочих губках. Длина 180 мм. Обеспечивает надёжную фиксацию игл.",
                Price = 1890.00m,
                Stock = 20,
                CategoryId = catInstrument.Id
            },
            new Product
            {
                Article = "RSB-PS001",
                Name = "Бинт марлевый стерильный 7м x 14см",
                Description = "Стерильный марлевый бинт для перевязки ран. Высокая впитываемость, гипоаллергенный. Индивидуальная стерильная упаковка. Соответствует ГОСТ 1172-93.",
                Price = 45.00m,
                Stock = 300,
                CategoryId = catBandage.Id
            },
            new Product
            {
                Article = "RSB-PS002",
                Name = "Салфетки марлевые стерильные 10x10 см",
                Description = "Стерильные марлевые салфетки для обработки ран и операционного поля. Упаковка 10 штук. 8 слоёв марли, высокая впитывающая способность.",
                Price = 120.00m,
                Stock = 200,
                CategoryId = catBandage.Id
            },
            new Product
            {
                Article = "RSB-IM001",
                Name = "Мембрана коллагеновая резорбируемая 20x30 мм",
                Description = "Биорезорбируемая коллагеновая мембрана для направленной тканевой регенерации. Срок резорбции 4-6 месяцев. Применяется в челюстно-лицевой хирургии и имплантологии.",
                Price = 8500.00m,
                Stock = 15,
                CategoryId = catImplant.Id
            },
            new Product
            {
                Article = "RSB-IM002",
                Name = "Костный заменитель гранулированный 0.5 г",
                Description = "Синтетический костный заменитель на основе гидроксиапатита. Гранулы 0.5-1.0 мм. Биосовместимый, остеокондуктивный. Применяется для заполнения костных дефектов.",
                Price = 12400.00m,
                Stock = 10,
                CategoryId = catImplant.Id
            },
            new Product
            {
                Article = "RSB-RM001",
                Name = "Перчатки хирургические латексные стерильные р.8",
                Description = "Стерильные хирургические перчатки из натурального латекса. Анатомическая форма, текстурированные пальцы. Размер 8. Упаковка 50 пар.",
                Price = 2200.00m,
                Stock = 80,
                CategoryId = catSupplies.Id
            }
        };

        context.Products.AddRange(products);
        await context.SaveChangesAsync();

        var savedProducts = context.Products.ToList();

        var imageMap = new Dictionary<string, string[]>
        {
            { "RSB-SH001", new[] { "/uploads/products/suture1.jpg" } },
            { "RSB-SH002", new[] { "/uploads/products/suture2.jpg" } },
            { "RSB-SH003", new[] { "/uploads/products/suture3.jpg" } },
            { "RSB-SH004", new[] { "/uploads/products/suture4.jpg" } },
            { "RSB-HI001", new[] { "/uploads/products/instrument1.jpg" } },
            { "RSB-HI002", new[] { "/uploads/products/scalpel1.jpg" } },
            { "RSB-HI003", new[] { "/uploads/products/instrument2.jpg" } },
            { "RSB-PS001", new[] { "/uploads/products/bandage1.jpg" } },
            { "RSB-PS002", new[] { "/uploads/products/bandage2.jpg" } },
            { "RSB-IM001", new[] { "/uploads/products/implant1.jpg" } },
            { "RSB-IM002", new[] { "/uploads/products/implant2.jpg" } },
            { "RSB-RM001", new[] { "/uploads/products/supplies1.jpg" } }
        };

        foreach (var product in savedProducts)
        {
            if (imageMap.ContainsKey(product.Article))
            {
                foreach (var imgPath in imageMap[product.Article])
                {
                    context.Set<ProductImage>().Add(new ProductImage
                    {
                        ProductId = product.Id,
                        ImagePath = imgPath
                    });
                }
            }
        }
        await context.SaveChangesAsync();

        client1 = await userManager.FindByEmailAsync(client1Email);
        client2 = await userManager.FindByEmailAsync(client2Email);

        var product1 = savedProducts.First(p => p.Article == "RSB-SH001");
        var product2 = savedProducts.First(p => p.Article == "RSB-HI002");
        var product3 = savedProducts.First(p => p.Article == "RSB-PS001");
        var product4 = savedProducts.First(p => p.Article == "RSB-IM001");

        var order1 = new Order
        {
            UserId = client1!.Id,
            FullName = client1.FullName,
            Phone = "+7 (495) 123-45-67",
            Email = client1.Email!,
            Address = "г. Москва, ул. Пирогова, д. 10, корп. 2",
            ClientType = ClientType.ФЛ,
            Status = OrderStatus.Выполнен,
            CreatedAt = DateTime.Now.AddDays(-14),
            TotalAmount = product1.Price * 5 + product2.Price * 20,
            Items = new List<OrderItem>
            {
                new OrderItem { ProductId = product1.Id, Quantity = 5, PriceAtMoment = product1.Price },
                new OrderItem { ProductId = product2.Id, Quantity = 20, PriceAtMoment = product2.Price }
            }
        };

        var order2 = new Order
        {
            UserId = client2!.Id,
            FullName = client2.FullName,
            Phone = "+7 (812) 987-65-43",
            Email = client2.Email!,
            Address = "г. Санкт-Петербург, Невский пр-т, д. 50",
            ClientType = ClientType.ЮЛ,
            CompanyName = "ООО \"Клиника Здоровье\"",
            Inn = "7801234567",
            ContactPerson = "Петрова А.В.",
            Status = OrderStatus.ВОбработке,
            CreatedAt = DateTime.Now.AddDays(-2),
            TotalAmount = product3.Price * 50 + product4.Price * 3,
            Items = new List<OrderItem>
            {
                new OrderItem { ProductId = product3.Id, Quantity = 50, PriceAtMoment = product3.Price },
                new OrderItem { ProductId = product4.Id, Quantity = 3, PriceAtMoment = product4.Price }
            }
        };

        var order3 = new Order
        {
            UserId = client1.Id,
            FullName = client1.FullName,
            Phone = "+7 (495) 123-45-67",
            Email = client1.Email!,
            Address = "г. Москва, ул. Пирогова, д. 10, корп. 2",
            ClientType = ClientType.ФЛ,
            Status = OrderStatus.Новый,
            CreatedAt = DateTime.Now,
            TotalAmount = product2.Price * 10,
            Items = new List<OrderItem>
            {
                new OrderItem { ProductId = product2.Id, Quantity = 10, PriceAtMoment = product2.Price }
            }
        };

        context.Orders.AddRange(order1, order2, order3);
        await context.SaveChangesAsync();
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
